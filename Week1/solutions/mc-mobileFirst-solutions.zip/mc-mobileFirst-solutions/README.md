# Mobile First
### `Morning Challenge | CSS, HTML`

## Learning objectives
- Practice mobile-first styling strategy

## Instructions
- Follow the mockups to make index.html match the mobile then desktop view
- The following color codes will be useful:
  header background: #fff
  body background: #dcc6bf
  footer background: #132D34