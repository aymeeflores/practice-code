# Title

### `Project type (non-abbreviated prefix) | related skill(s) if any`

## Learning objectives

- SASS
- Using mixins and variables
- Bonus: Animations and keyframes

## Instructions

- Follow the instructions in the index.html file.
  (Don't forget to open the html file with live server so you get live updates!)
