# Demo: HTML, CSS, VS Code

## Day 3: CSS Specificity
