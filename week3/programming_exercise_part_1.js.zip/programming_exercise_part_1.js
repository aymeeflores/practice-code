/* Follow the instructions below */

// e.g. Print out the string 'Hello World'
console.log('Hello World')

// Create a variable called 'a' with the value of 1

// Check the type of 'a' using 'typeof'. Use console.log() to see the result

// Create another variable called 'b' with the value of 2

// Create another variable called 'sum' that is
// the result of adding 'a' and 'b' together

// Print out the sum

// Print out the value of 10 divided by 3

// Print out the remainder of 10 divided by 3 using %

// Print out the value of 1 + '1'. 
// What is the result? Why? How could you get the expected result?

