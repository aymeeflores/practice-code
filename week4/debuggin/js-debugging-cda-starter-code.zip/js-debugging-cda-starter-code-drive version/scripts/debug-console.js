const locations = ["new york", "london", "toronto", "vancouver", "miami"];
const student = {
  firstName: "John",
  lastName: "Doe",
  course: "Web Development",
};

// different ways to console.log information in web console
// ADD YOUR CODE AFTER THIS LINE
