import Card from './Card';

function CardList(props) {
  // create an array to store info for the 2 cards here

  return (
    <section className="card-list">
      {/* replace the card below by using the Array .map method */}
      <Card />
    </section>
  );
}

export default CardList;
