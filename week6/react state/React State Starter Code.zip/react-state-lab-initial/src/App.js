import './App.scss'
import Header from './components/Header'
import CardList from './components/CardList'

function App() {
  return (
    <>
      <Header logo="BrainStation"/>
      <CardList/>
    </>
  );
}

export default App;
