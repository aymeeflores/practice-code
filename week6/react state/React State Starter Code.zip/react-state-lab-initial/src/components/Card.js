import React, { Component } from 'react';

class Card extends Component {
    render() {
        return (
            <div 
              className="card" 
              onClick={
                (event) => this.props.clickHandler(event, this.props.title)
              }
            >
                <div className="card__content">
                    {this.props.content}
                </div>
                <h4 className="card__title">
                    {this.props.title}
                </h4>
            </div>
        );
    }
}

export default Card;